cat youho/switch >/proc/switch
cat youho/file_list >/proc/file_list
cat youho/role_list >/proc/role_list
cat youho/relation  >/proc/relation
